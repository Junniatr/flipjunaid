
# 🛍️ FlipJunaid

**This is an online shopping website created by Junaid.**

---

## 🌟 Features

- 🏠 Home Page with products  
- ➕ Add to Cart  
- 💵 Checkout page  
- 🔐 Admin Panel (add/delete products)  
- 🌙 Dark Mode toggle  
- 📦 Product detail page  
- 🔐 Signup & Login  
- 📱 Fully responsive

---

## 🔗 Live Link

[👉 Click here to visit the site](https://Junniatr.github.io/flipjunaid/)

---

## 🖼️ Screenshots

### 🏠 Homepage

![Homepage Screenshot](https://i.imgur.com/QgM8gDj.png)

---

### 🛒 Cart & Checkout Page

![Cart Screenshot](https://i.imgur.com/nL2c3zy.png)

---

### 🔐 Admin Panel

![Admin Screenshot](https://i.imgur.com/9FxKjgz.png)

---

### 🌙 Dark Mode

![Dark Mode Screenshot](https://i.imgur.com/YNYrM3c.png)

---

## 👨‍💻 Made by:

**Junaid**  
📞 8951267402  
📧 junniatr26@email.com
